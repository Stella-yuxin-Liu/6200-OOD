package edu.neu.csye6200;

public class ExplosionAModel {
    System.out.println("ExplosionAModel Demo:");
    AbstractExplosion obj;
    obj = new AGunshot();
    obj.explode();
    obj = new AGrenade();
    obj.explode();
    obj = new ABomb();
    obj.explode();
    System.out.println("ExplosionAModel Demo End.");
}