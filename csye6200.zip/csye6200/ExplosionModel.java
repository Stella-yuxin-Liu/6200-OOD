package edu.neu.csye6200;

public class ExplosionModel {
    System.out.println("ExplosionModel Demo:");
    AbstractExplosion obj;
    obj = new Gunshot();
    obj.explode();
    obj = new Grenade();
    obj.explode();
    obj = new Bomb();
    obj.explode();
    System.out.println("ExplosionModel Demo End.");
}