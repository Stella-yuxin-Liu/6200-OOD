package edu.neu.csye6200;

public class Bomb implements ExplodableAPI {
    @Override
    public void explode() {
        System.out.println("Bomb: ** Splatter **");
    }
}