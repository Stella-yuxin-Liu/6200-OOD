package edu.neu.csye6200;

public interface ExplodableAPI {
	public void explode();
}