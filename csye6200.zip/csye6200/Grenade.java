package edu.neu.csye6200;

public class Grenade implements ExplodableAPI {
    @Override
    public void explode() {
        System.out.println("Grenade: ** Splatter **");
    }
}