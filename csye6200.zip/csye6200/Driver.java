package edu.neu.csye6200;

public class Driver {
    public static void main(String[] args) {
        ExplosionAModel eam = new ExplosionAModel();
        eam.demo();
        ExplosionModel em = new ExplosionModel();
        em.demo();
    }
}