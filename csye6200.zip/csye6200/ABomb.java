package edu.neu.csye6200;

public class ABomb extends AbstractExplosion {
    @Override
    public void explode() {
        System.out.println("ABomb: ** KABOOM **");
    }
}