package edu.neu.csye6200;

public class Gunshot implements ExplodableAPI {
    @Override
    public void explode() {
        System.out.println("Gunshot: ** Splatter **");
    }
}