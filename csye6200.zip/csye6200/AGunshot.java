package edu.neu.csye6200;

public class AGunshot extends AbstractExplosion {
    @Override
    public void explode() {
        System.out.println("AGunshot: ** KABOOM **");
    }
}