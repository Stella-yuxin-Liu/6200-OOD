/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Air
 */
public class LisInfo {
    private String LicenseNum;
    private String dateitwasissued;
    private String Dateofexpiration;
    private String Bloodtype;
    private String picturepath;

    public String getLicenseNum() {
        return LicenseNum;
    }

    public void setLicenseNum(String LicenseNum) {
        this.LicenseNum = LicenseNum;
    }

    public String getDateitwasissued() {
        return dateitwasissued;
    }

    public void setDateitwasissued(String dateitwasissued) {
        this.dateitwasissued = dateitwasissued;
    }

    public String getDateofexpiration() {
        return Dateofexpiration;
    }

    public void setDateofexpiration(String Dateofexpiration) {
        this.Dateofexpiration = Dateofexpiration;
    }

    public String getBloodtype() {
        return Bloodtype;
    }

    public void setBloodtype(String Bloodtype) {
        this.Bloodtype = Bloodtype;
    }

    public String getPicturepath() {
        return picturepath;
    }

    public void setPicturepath(String picturepath) {
        this.picturepath = picturepath;
    }
    
    
}
