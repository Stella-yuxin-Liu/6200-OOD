/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Air
 */
public class SavingInfo {
    private String Bankname;
    private String bankroutingNum;
    private String bankaccountNum;
    private String accountbalance;
    private String accounttypesaving;

    public String getBankname() {
        return Bankname;
    }

    public void setBankname(String Bankname) {
        this.Bankname = Bankname;
    }

    public String getBankroutingNum() {
        return bankroutingNum;
    }

    public void setBankroutingNum(String bankroutingNum) {
        this.bankroutingNum = bankroutingNum;
    }

    public String getBankaccountNum() {
        return bankaccountNum;
    }

    public void setBankaccountNum(String bankaccountNum) {
        this.bankaccountNum = bankaccountNum;
    }

    public String getAccountbalance() {
        return accountbalance;
    }

    public void setAccountbalance(String accountbalance) {
        this.accountbalance = accountbalance;
    }

    public String getAccounttypesaving() {
        return accounttypesaving;
    }

    public void setAccounttypesaving(String accounttypesaving) {
        this.accounttypesaving = accounttypesaving;
    }
    
}
