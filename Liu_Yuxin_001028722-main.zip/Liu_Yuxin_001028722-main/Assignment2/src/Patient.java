/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Air
 */

import java.util.ArrayList;
import java.util.List;

public class Patient {
	private String patientID;
	private String firstName;
	private String lastName;
	private String ageGroup;
	private VitalSign currentVitalSign;
	private ArrayList<VitalSign> vitalSignHistory;
	
	public Patient(String patientID, String firstName, String lastName, String ageGroup) {
		super();
		this.patientID = patientID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.ageGroup = ageGroup;
		this.vitalSignHistory = new ArrayList<>();
	}
	
	public boolean isPatientNormal() {
		return isVitalSignNormal(currentVitalSign);
	}
	
	public boolean isVitalSignNormal(VitalSign vitalSign) {
		if (vitalSign == null) {
			System.out.println("ERROR: NULL Vital Sign!");
			return false;
		}
		boolean flag = true;
		switch(ageGroup) {
		case "Newborn":
			if (!inRange(vitalSign.getRespiratoryRate(), 30, 50)) {
				System.out.println("WARNING: Abnormal Respiratory Rate!");
				flag = false;
			}
			if (!inRange(vitalSign.getHeartRate(), 120, 160)) {
				System.out.println("WARNING: Abnormal Heart Rate!");
				flag = false;
			}
			if (!inRange(vitalSign.getSystolicBloodPressure(), 50, 70)) {
				System.out.println("WARNING: Abnormal Systolic Blood Pressure!");
				flag = false;
			}
			if (!inRange(vitalSign.getWeightKilo(), 2, 3)) {
				System.out.println("WARNING: Abnormal Weight in Kilo!");
				flag = false;
			}
			if (!inRange(vitalSign.getWeightPound(), 4.5, 7)) {
				System.out.println("WARNING: Abnormal Weight in Pound!");
				flag = false;
			}
			if (flag) {
				System.out.println("NORMAL!");
			}
			return flag;
		case "Infant":
			if (!inRange(vitalSign.getRespiratoryRate(), 20, 30)) {
				System.out.println("WARNING: Abnormal Respiratory Rate!");
				flag = false;
			}
			if (!inRange(vitalSign.getHeartRate(), 80, 140)) {
				System.out.println("WARNING: Abnormal Heart Rate!");
				flag = false;
			}
			if (!inRange(vitalSign.getSystolicBloodPressure(), 70, 100)) {
				System.out.println("WARNING: Abnormal Systolic Blood Pressure!");
				flag = false;
			}
			if (!inRange(vitalSign.getWeightKilo(), 4, 10)) {
				System.out.println("WARNING: Abnormal Weight in Kilo!");
				flag = false;
			}
			if (!inRange(vitalSign.getWeightPound(), 9, 22)) {
				System.out.println("WARNING: Abnormal Weight in Pound!");
				flag = false;
			}
			if (flag) {
				System.out.println("NORMAL!");
			}
			return flag;
		case "Toddler":
			if (!inRange(vitalSign.getRespiratoryRate(), 20, 30)) {
				System.out.println("WARNING: Abnormal Respiratory Rate!");
				flag = false;
			}
			if (!inRange(vitalSign.getHeartRate(), 80, 130)) {
				System.out.println("WARNING: Abnormal Heart Rate!");
				flag = false;
			}
			if (!inRange(vitalSign.getSystolicBloodPressure(), 80, 110)) {
				System.out.println("WARNING: Abnormal Systolic Blood Pressure!");
				flag = false;
			}
			if (!inRange(vitalSign.getWeightKilo(), 10, 14)) {
				System.out.println("WARNING: Abnormal Weight in Kilo!");
				flag = false;
			}
			if (!inRange(vitalSign.getWeightPound(), 22, 31)) {
				System.out.println("WARNING: Abnormal Weight in Pound!");
				flag = false;
			}
			if (flag) {
				System.out.println("NORMAL!");
			}
			return flag;
		case "Preschooler":
			if (!inRange(vitalSign.getRespiratoryRate(), 20, 30)) {
				System.out.println("WARNING: Abnormal Respiratory Rate!");
				flag = false;
			}
			if (!inRange(vitalSign.getHeartRate(), 80, 120)) {
				System.out.println("WARNING: Abnormal Heart Rate!");
				flag = false;
			}
			if (!inRange(vitalSign.getSystolicBloodPressure(), 80, 110)) {
				System.out.println("WARNING: Abnormal Systolic Blood Pressure!");
				flag = false;
			}
			if (!inRange(vitalSign.getWeightKilo(), 14, 18)) {
				System.out.println("WARNING: Abnormal Weight in Kilo!");
				flag = false;
			}
			if (!inRange(vitalSign.getWeightPound(), 31, 40)) {
				System.out.println("WARNING: Abnormal Weight in Pound!");
				flag = false;
			}
			if (flag) {
				System.out.println("NORMAL!");
			}
			return flag;
		case "SchoolAge":
			if (!inRange(vitalSign.getRespiratoryRate(), 20, 30)) {
				System.out.println("WARNING: Abnormal Respiratory Rate!");
				flag = false;
			}
			if (!inRange(vitalSign.getHeartRate(), 70, 110)) {
				System.out.println("WARNING: Abnormal Heart Rate!");
				flag = false;
			}
			if (!inRange(vitalSign.getSystolicBloodPressure(), 80, 120)) {
				System.out.println("WARNING: Abnormal Systolic Blood Pressure!");
				flag = false;
			}
			if (!inRange(vitalSign.getWeightKilo(), 20, 42)) {
				System.out.println("WARNING: Abnormal Weight in Kilo!");
				flag = false;
			}
			if (!inRange(vitalSign.getWeightPound(), 41, 92)) {
				System.out.println("WARNING: Abnormal Weight in Pound!");
				flag = false;
			}
			if (flag) {
				System.out.println("NORMAL!");
			}
			return flag;
		case "Adolescent":
			if (!inRange(vitalSign.getRespiratoryRate(), 12, 20)) {
				System.out.println("WARNING: Abnormal Respiratory Rate!");
				flag = false;
			}
			if (!inRange(vitalSign.getHeartRate(), 55, 105)) {
				System.out.println("WARNING: Abnormal Heart Rate!");
				flag = false;
			}
			if (!inRange(vitalSign.getSystolicBloodPressure(), 110, 120)) {
				System.out.println("WARNING: Abnormal Systolic Blood Pressure!");
				flag = false;
			}
			if (vitalSign.getWeightKilo() < 50) {
				System.out.println("WARNING: Abnormal Weight in Kilo!");
				flag = false;
			}
			if (vitalSign.getWeightPound() < 110) {
				System.out.println("WARNING: Abnormal Weight in Pound!");
				flag = false;
			}
			if (flag) {
				System.out.println("NORMAL!");
			}
			return flag;
		default:
			System.out.println("ERROR: Wrongful Age Group!");
			return false;
		}
	}
	
	public void newVitalSign(VitalSign newVitalSign) {
		currentVitalSign = newVitalSign;
		if (currentVitalSign != null) {
			vitalSignHistory.add(currentVitalSign);
		}
	}
	
	public boolean isThisVitalSignNormal(String vitalSignName) {
		for (VitalSign vs : vitalSignHistory) {
			if (vs.getVitalSignName().equals(vitalSignName)) {
				return isVitalSignNormal(vs);
			}
		}
		System.out.println("ERROR: No Requested Vital Sign Found!");
		return false;
	}
	
	private boolean inRange(int i, int min, int max) {
		return Math.max(min, i) == Math.min(i, max);
	}
	
	private boolean inRange(double i, double min, double max) {
		return Math.max(min, i) == Math.min(i, max);
	}

	@Override
	public String toString() {
		String result = "Patient [\nPatient ID = " + patientID + ", First Name = " + firstName + ", Last Name = " + lastName + ", Age Group = "
				+ ageGroup + ", \nCurrent Vital Sign:\n";
		if (currentVitalSign != null) {
			result += currentVitalSign.toString();
		} else {
			result += "NULL";
		}
		result  += ", \nVital Sign History:\n";
		if (vitalSignHistory != null) {
			for (VitalSign vs : vitalSignHistory) {
				result += (vs.toString() + ", \n");
			}
		} else {
			result += "NULL, \n";
		}
		result += "]";
		return result;
	}

	public String getPatientID() {
		return patientID;
	}

	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}

	public VitalSign getCurrentVitalSign() {
		return currentVitalSign;
	}

	public void setCurrentVitalSign(VitalSign currentVitalSign) {
		this.currentVitalSign = currentVitalSign;
	}

	public ArrayList<VitalSign> getVitalSignHistory() {
		return vitalSignHistory;
	}

	public void setVitalSignHistory(ArrayList<VitalSign> vitalSignHistory) {
		this.vitalSignHistory = vitalSignHistory;
	}
}
