/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Air
 */
public class VitalSign {
	private String vitalSignName;
	private int respiratoryRate;
	private int heartRate;
	private int systolicBloodPressure;
	private double weightKilo;
	private double weightPound;
	
	public VitalSign(String vitalSignName, int respiratoryRate, int heartRate, int systolicBloodPressure, double weightKilo,
			double weightPound) {
		super();
		this.vitalSignName = vitalSignName;
		this.respiratoryRate = respiratoryRate;
		this.heartRate = heartRate;
		this.systolicBloodPressure = systolicBloodPressure;
		this.weightKilo = weightKilo;
		this.weightPound = weightPound;
	}

	@Override
	public String toString() {
		return "VitalSign [Vital Sign Name = " + vitalSignName + ", Respiratory Rate = " + respiratoryRate + ", Heart Rate = "
				+ heartRate + ", Systolic Blood Pressure = " + systolicBloodPressure + ", Weight in Kilo = " + weightKilo
				+ ", Weight Pound = " + weightPound + "]";
	}
	
	public String getVitalSignName() {
		return vitalSignName;
	}
	
	public void setVitalSignName(String vitalSignName) {
		this.vitalSignName = vitalSignName;
	}

	public int getRespiratoryRate() {
		return respiratoryRate;
	}

	public void setRespiratoryRate(int respiratoryRate) {
		this.respiratoryRate = respiratoryRate;
	}

	public int getHeartRate() {
		return heartRate;
	}

	public void setHeartRate(int heartRate) {
		this.heartRate = heartRate;
	}

	public int getSystolicBloodPressure() {
		return systolicBloodPressure;
	}

	public void setSystolicBloodPressure(int systolicBloodPressure) {
		this.systolicBloodPressure = systolicBloodPressure;
	}

	public double getWeightKilo() {
		return weightKilo;
	}

	public void setWeightKilo(double weightKilo) {
		this.weightKilo = weightKilo;
	}

	public double getWeightPound() {
		return weightPound;
	}

	public void setWeightPound(double weightPound) {
		this.weightPound = weightPound;
	}
}
