/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Air
 */
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		Patient patient;
		String patientID;
		String firstName;
		String lastName;
		int operationCode = 0;
		String ageGroup;
		
		VitalSign vitalSign;
		String vitalSignName;
		int respiratoryRate;
		int heartRate;
		int systolicBloodPressure;
		double weightKilo;
		double weightPound;
		
		System.out.println("Welcome to Patient-VitalSign Management System!");
		System.out.println("Create Patient:\nPlease Enter Patient ID:");
		patientID = sc.nextLine();
		System.out.println("Please Enter First Name:");
		firstName = sc.nextLine();
		System.out.println("Please Enter Last Name:");
		lastName = sc.nextLine();
		x1:while (true) {
			System.out.println("Please Enter Age Group Number:\n1.Newborn;\n2.Infant;\n3.Toddler;\n4.Preschooler;\n5.SchoolAge;\n6.Adolescent;\nAGE GROUP:");
			operationCode = sc.nextInt();
			switch(operationCode) {
			case 1:
				ageGroup = "Newborn";
				break x1;
			case 2:
				ageGroup = "Infant";
				break x1;
			case 3:
				ageGroup = "Toddler";
				break x1;
			case 4:
				ageGroup = "Preschooler";
				break x1;
			case 5:
				ageGroup = "SchoolAge";
				break x1;
			case 6:
				ageGroup = "Adolescent";
				break x1;
			default:
				System.out.println("ERROR: Nonexistent Group!");
				continue x1;
			}
		}
		patient = new Patient(patientID, firstName, lastName, ageGroup);

		operationCode = 0;
		x2:while (true) {
			System.out.println("Please Enter your Operation:\n1.View Patient;\n2.Add Vital Sign;\n3.Is Patient Normal;\n4.Is This Vital Sign Normal;\n5.Exit\nOPERATION:");
			operationCode = sc.nextInt();
			x3:switch(operationCode) {
			case 1:
				System.out.println(patient.toString());
				break x3;
			case 2:
				sc = new Scanner(System.in);
				System.out.println("Create Vital Sign:\nPlease Enter Vital Sign Name:");
				vitalSignName = sc.nextLine();
				System.out.println("Please Enter Respiratory Rate:");
				respiratoryRate = sc.nextInt();
				System.out.println("Please Enter Heart Rate:");
				heartRate = sc.nextInt();
				System.out.println("Please Enter Systolic Blood Pressure:");
				systolicBloodPressure = sc.nextInt();
				System.out.println("Please Enter Weight in Kilo:");
				weightKilo = sc.nextDouble();
				System.out.println("Please Enter Weight in Pound:");
				weightPound = sc.nextDouble();
				vitalSign = new VitalSign(vitalSignName, respiratoryRate, heartRate, systolicBloodPressure, weightKilo, weightPound);
				patient.newVitalSign(vitalSign);
				break x3;
			case 3:
				if (!patient.isPatientNormal()) {
					System.out.println("WARNING: Abnormal Patient!");
				} else {
					System.out.println("SAFE: Normal Patient!");
				}
				break x3;
			case 4:
				sc = new Scanner(System.in);
				System.out.println("Please Enter Vital Sign Name:");
				vitalSignName = sc.nextLine();
				if (!patient.isThisVitalSignNormal(vitalSignName)) {
					System.out.println("WARNING: Abnormal Patient!");
				} else {
					System.out.println("SAFE: Normal Vital Sign!");
				}
				break x3;
			case 5:
				break x2;
			default:
				System.out.println("ERROR: Nonexistent Operation!");
				continue x2;
			}
		}
	}

}

