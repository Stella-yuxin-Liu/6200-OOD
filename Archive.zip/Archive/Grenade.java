package edu.neu.csye6200;

public class Grenade extends AbstractExplosion {
	@Override
	public void explode() {
	System.out.println("AGrenade: ** KABOOM **");
	}
}