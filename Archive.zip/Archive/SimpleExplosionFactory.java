package edu.neu.csye6200;

public class SimpleExplosionFactory {
	enum ExplosionCriteria {
		GUNSHOT,
		GRENADE
	}
	public AbstractExplosion getObject (ExplosionCriteria criteria) {
		if (criteria == GUNSHOT) {
			return new GunShot();
		}
		return new Grenade()；
	}
}