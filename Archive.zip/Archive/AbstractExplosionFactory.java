package edu.neu.csye6200;

public abstract class AbstractExplosionFactory {
	public abstract AbstractExplosion getObject();
}