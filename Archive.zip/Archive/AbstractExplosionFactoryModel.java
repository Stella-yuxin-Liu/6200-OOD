package edu.neu.csye6200;

public class AbstractExplosionFactoryModel {
	public static void demo() {
		AbstractExplosionFactory factory1 = new GunShotFactory();
		AbstractExplosionFactory factory2 = new GrenadeFactory();
		List<AbstractExplosion> explosions = new ArrayList<>();
		explosions.add(factory1.getObject());
		explosions.add(factory2.getObject());
		for (AbstractExplosion ae : explosions) {
			ae.explode();
		}
	}
}