package edu.neu.csye6200;

public abstract class AbstractExplosion {
	public abstract void explode();
}