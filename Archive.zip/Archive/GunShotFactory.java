package edu.neu.csye6200;

public class GunShotFactory extends AbstractExplosionFactory {
	public abstract AbstractExplosion getObject() {
	return new GunShot();
	}
}