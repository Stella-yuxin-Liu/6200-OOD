package edu.neu.csye6200;

public abstract class GunShot extends AbstractExplosion {
	@Override
	public abstract void explode() {
		System.out.println("AGunshot: ** KABOOM **");
	}
}