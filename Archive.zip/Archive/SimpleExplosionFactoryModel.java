package edu.neu.csye6200;

public SimpleExplosionFactoryModel {
	public static void demo() {
		SimpleExplosionFactory factory = new SimpleExplosionFactory();
		List<AbstractExplosion> explosions = new ArrayList<>();
		explosions.add(factory.getObject(GUNSHOT));
		explosions.add(factory.getObject(GRENADE));
		for (AbstractExplosion ae : explosions) {
			ae.explode();
		}
	}
}