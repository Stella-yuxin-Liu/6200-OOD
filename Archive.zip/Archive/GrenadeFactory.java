package edu.neu.csye6200;

public class GrenadeFactory extends AbstractExplosionFactory {
	public abstract AbstractExplosion getObject() {
	return new Grenade();
	}
}