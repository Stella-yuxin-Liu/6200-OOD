package edu.neu.csye6200;
import java.util.Comparator;


public abstract class AbstractSchoolAPI {
	public abstract void addTeacher(Teacher s);
	public abstract void addStudent(Student s);
	public abstract void sortTeachers(Comparator c);
	public abstract void sortStudents(Comparator c);

}
