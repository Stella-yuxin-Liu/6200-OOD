package edu.neu.csye6200;
import java.util.Comparator;

public class SortTeacherByEmployeeID implements Comparator<Teacher> {
	@Override
		public int compare(Teacher s1, Teacher s2) {
		return s1.getEmployeeID().compareTo(s2.getEmployeeID());
		
	}
}