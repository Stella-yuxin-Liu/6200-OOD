package edu.neu.csye6200;

import java.util.Comparator;

public class SortTeacherByWage implements Comparator<Teacher> {
	@Override
		public int compare(Teacher s1, Teacher s2) {
		return Double.compare(s1.getwage(),s2.getwage());
	}
}