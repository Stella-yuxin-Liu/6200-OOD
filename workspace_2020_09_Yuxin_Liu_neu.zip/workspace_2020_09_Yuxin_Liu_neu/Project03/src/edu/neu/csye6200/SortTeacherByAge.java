package edu.neu.csye6200;

import java.util.Comparator;

public class SortTeacherByAge implements Comparator<Teacher> {
	@Override
		public int compare(Teacher s1, Teacher s2) {
		return s1.getAge()-s1.getAge();
		
	}
}