package edu.neu.csye6200;



public class Teacher {
		private String EmployeeID;
		private String Firstname;
		private String Lastname;
		int Age;
		double wage;
	
		

	
		public Teacher(String EmployeeID, String Firstname, String Lastname, int Age, double wage) {
			this.EmployeeID = EmployeeID;
			this.Firstname = Firstname;
			this.Lastname = Lastname;
			this.Age = Age;
			this.wage = wage;
		}


	public String toString() {
		return "Teacher [EmployeeID=" +EmployeeID+ ", Firstname=" +Firstname+ ", Lastname=" +Lastname+ ", Age=" +Age+ ","
				+ "wage=" +wage+ "]";
	}
		
	public void setEmployeeID(String EmployeeID) {
		this.EmployeeID = EmployeeID;
	}
	public void setFirstname(String Firstname) {
		this.Firstname = Firstname;
	}
	public void setLastname(String Lastname) {
		this.Lastname = Lastname;
	}
	public void setage(int Age) {
		this.Age = Age;
	}
	public void setwage(double wage) {
		this.wage = wage;
	}
	public String getEmployeeID() {
		return EmployeeID;
	}
	public String getFirstname() {
		return Firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public int getAge() {
		return Age;
	}
	public double getwage() {
		return wage;
	}

}
