package edu.neu.csye6200;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class NEU extends AbstractSchoolAPI {
	List<Teacher>teachers = new ArrayList<Teacher>();
	List<Student>students = new ArrayList<Student>();
	@Override
	public void sortTeachers(Comparator c) {
		Collections.sort(teachers,c);
	}
	@Override
	public void sortStudents(Comparator c) {
		Collections.sort(students,c);
	}

	public void demo() {
		 teachers.add(new Teacher("10010","Jack","Zhang",43,25600.6));
		 teachers.add(new Teacher("10016","Mark","Wong",53,25687.7));
		 teachers.add(new Teacher("10013","Lisa","White",63,76578.77));
		 teachers.add(new Teacher("10012","Donald","Trump",73,25879.6));
		 teachers.add(new Teacher("12354","Kitty","Blue",52,56980.9));
		 
		 students.add(new Student("0323","Mike","Lee",23,3.2));
		 students.add(new Student("0724","Peter","Black",71,2.2));
		 students.add(new Student("0213","Stella","Lou",34,3.8));
		 students.add(new Student("0823","Ling","Xiao",33,3.5));
		 students.add(new Student("8972","Zoey","Adams",21,3.3));
		
		 sortTeachers(new SortTeacherByEmployeeID());
		 for(Teacher t: teachers) {
		 System.out.println(t.toString());
		 }
		 sortTeachers(new SortTeacherByFName());
		 for(Teacher t: teachers) {
		 System.out.println(t.toString());
		 }
		 sortTeachers(new SortTeacherByLName());
		 for(Teacher t: teachers) {
		 System.out.println(t.toString());
		 }
		 sortTeachers(new SortTeacherByAge());
		 for(Teacher t: teachers) {
		 System.out.println(t.toString());
		 }
		 sortTeachers(new SortTeacherByWage());
		 for(Teacher t: teachers) {
		 System.out.println(t.toString());
		 }
		 sortStudents(new SortStudentByStudentID());
		 for(Student t: students) {
		 System.out.println(t.toString());
		 }
		 sortStudents(new SortStudentByFName());
		 for(Student t: students) {
		 System.out.println(t.toString());
		 }
		 sortStudents(new SortStudentByLName());
		 for(Student t: students) {
		 System.out.println(t.toString());
		 }
		 sortStudents(new SortStudentByAge());
		 for(Student t: students) {
		 System.out.println(t.toString());
		 }
		 sortStudents(new SortStudentByGPA());
		 for(Student t: students) {
		 System.out.println(t.toString());
		 }
	}
}

		   	