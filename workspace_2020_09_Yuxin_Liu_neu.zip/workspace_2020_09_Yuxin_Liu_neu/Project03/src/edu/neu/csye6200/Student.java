package edu.neu.csye6200;



public class Student {
	private String StudentID;
	private String Firstname;
	private String Lastname;
	int Age;
	double GPA;

	public Student(String StudentID, String Firstname, String Lastname, int Age, double GPA) {
		this.StudentID = StudentID;
		this.Firstname = Firstname;
		this.Lastname = Lastname;
		this.Age = Age;
		this.GPA = GPA;
		
	}	
	public String toString() {
	return "Student [StudentID=" +StudentID+ ", Firstname=" +Firstname+ ", Lastname=" +Lastname+ ", Age=" +Age+ ","
			+ "GPA=" +GPA+ "]";
}
	
	public void setStudentID(String StudentID) {
		this.StudentID = StudentID;
	}
	public void setFirstname(String Firstname) {
		this.Firstname = Firstname;
	}
	public void setLastname(String Lastname) {
		this.Lastname = Lastname;
	}
	public void setage(int Age) {
		this.Age = Age;
	}
	public void setGPA(double GPA) {
		this.GPA = GPA;
	}

	public String getStudentID() {
		return StudentID;
	}
	public String getFirstname() {
		return Firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public int getAge() {
		return Age;
	}
	public double getGPA() {
		return GPA;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
	
