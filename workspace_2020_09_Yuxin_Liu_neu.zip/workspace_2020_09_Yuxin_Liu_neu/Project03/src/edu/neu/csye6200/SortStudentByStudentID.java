package edu.neu.csye6200;

import java.util.Comparator;

public class SortStudentByStudentID implements Comparator<Student> {
	@Override
		public int compare(Student s1, Student s2) {
		return s1.getStudentID().compareTo(s2.getStudentID());
		
	}
}