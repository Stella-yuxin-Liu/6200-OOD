package edu.neu.csye6200;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Driver {

	public static void main(String[] args) {
	NEU neu = new NEU();
	neu.demo();
	}
	
}
/*
 * Teacher [EmployeeID=10010, Firstname=Jack, Lastname=Zhang, Age=43,wage=25600.6]
Teacher [EmployeeID=10012, Firstname=Donald, Lastname=Trump, Age=73,wage=25879.6]
Teacher [EmployeeID=10013, Firstname=Lisa, Lastname=White, Age=63,wage=76578.77]
Teacher [EmployeeID=10016, Firstname=Mark, Lastname=Wong, Age=53,wage=25687.7]
Teacher [EmployeeID=12354, Firstname=Kitty, Lastname=Blue, Age=52,wage=56980.9]
Teacher [EmployeeID=10012, Firstname=Donald, Lastname=Trump, Age=73,wage=25879.6]
Teacher [EmployeeID=10010, Firstname=Jack, Lastname=Zhang, Age=43,wage=25600.6]
Teacher [EmployeeID=12354, Firstname=Kitty, Lastname=Blue, Age=52,wage=56980.9]
Teacher [EmployeeID=10013, Firstname=Lisa, Lastname=White, Age=63,wage=76578.77]
Teacher [EmployeeID=10016, Firstname=Mark, Lastname=Wong, Age=53,wage=25687.7]
Teacher [EmployeeID=12354, Firstname=Kitty, Lastname=Blue, Age=52,wage=56980.9]
Teacher [EmployeeID=10012, Firstname=Donald, Lastname=Trump, Age=73,wage=25879.6]
Teacher [EmployeeID=10013, Firstname=Lisa, Lastname=White, Age=63,wage=76578.77]
Teacher [EmployeeID=10016, Firstname=Mark, Lastname=Wong, Age=53,wage=25687.7]
Teacher [EmployeeID=10010, Firstname=Jack, Lastname=Zhang, Age=43,wage=25600.6]
Teacher [EmployeeID=12354, Firstname=Kitty, Lastname=Blue, Age=52,wage=56980.9]
Teacher [EmployeeID=10012, Firstname=Donald, Lastname=Trump, Age=73,wage=25879.6]
Teacher [EmployeeID=10013, Firstname=Lisa, Lastname=White, Age=63,wage=76578.77]
Teacher [EmployeeID=10016, Firstname=Mark, Lastname=Wong, Age=53,wage=25687.7]
Teacher [EmployeeID=10010, Firstname=Jack, Lastname=Zhang, Age=43,wage=25600.6]
Teacher [EmployeeID=10010, Firstname=Jack, Lastname=Zhang, Age=43,wage=25600.6]
Teacher [EmployeeID=10016, Firstname=Mark, Lastname=Wong, Age=53,wage=25687.7]
Teacher [EmployeeID=10012, Firstname=Donald, Lastname=Trump, Age=73,wage=25879.6]
Teacher [EmployeeID=12354, Firstname=Kitty, Lastname=Blue, Age=52,wage=56980.9]
Teacher [EmployeeID=10013, Firstname=Lisa, Lastname=White, Age=63,wage=76578.77]
Student [StudentID=0213, Firstname=Stella, Lastname=Lou, Age=34,GPA=3.8]
Student [StudentID=0323, Firstname=Mike, Lastname=Lee, Age=23,GPA=3.2]
Student [StudentID=0724, Firstname=Peter, Lastname=Black, Age=71,GPA=2.2]
Student [StudentID=0823, Firstname=Ling, Lastname=Xiao, Age=33,GPA=3.5]
Student [StudentID=8972, Firstname=Zoey, Lastname=Adams, Age=21,GPA=3.3]
Student [StudentID=0823, Firstname=Ling, Lastname=Xiao, Age=33,GPA=3.5]
Student [StudentID=0323, Firstname=Mike, Lastname=Lee, Age=23,GPA=3.2]
Student [StudentID=0724, Firstname=Peter, Lastname=Black, Age=71,GPA=2.2]
Student [StudentID=0213, Firstname=Stella, Lastname=Lou, Age=34,GPA=3.8]
Student [StudentID=8972, Firstname=Zoey, Lastname=Adams, Age=21,GPA=3.3]
Student [StudentID=8972, Firstname=Zoey, Lastname=Adams, Age=21,GPA=3.3]
Student [StudentID=0724, Firstname=Peter, Lastname=Black, Age=71,GPA=2.2]
Student [StudentID=0323, Firstname=Mike, Lastname=Lee, Age=23,GPA=3.2]
Student [StudentID=0213, Firstname=Stella, Lastname=Lou, Age=34,GPA=3.8]
Student [StudentID=0823, Firstname=Ling, Lastname=Xiao, Age=33,GPA=3.5]
Student [StudentID=8972, Firstname=Zoey, Lastname=Adams, Age=21,GPA=3.3]
Student [StudentID=0724, Firstname=Peter, Lastname=Black, Age=71,GPA=2.2]
Student [StudentID=0323, Firstname=Mike, Lastname=Lee, Age=23,GPA=3.2]
Student [StudentID=0213, Firstname=Stella, Lastname=Lou, Age=34,GPA=3.8]
Student [StudentID=0823, Firstname=Ling, Lastname=Xiao, Age=33,GPA=3.5]
Student [StudentID=0724, Firstname=Peter, Lastname=Black, Age=71,GPA=2.2]
Student [StudentID=0323, Firstname=Mike, Lastname=Lee, Age=23,GPA=3.2]
Student [StudentID=8972, Firstname=Zoey, Lastname=Adams, Age=21,GPA=3.3]
Student [StudentID=0823, Firstname=Ling, Lastname=Xiao, Age=33,GPA=3.5]
Student [StudentID=0213, Firstname=Stella, Lastname=Lou, Age=34,GPA=3.8]
              
 */