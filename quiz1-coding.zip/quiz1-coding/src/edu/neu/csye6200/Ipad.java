package edu.neu.csye6200;

public class Ipad {
	private String serialNum;
	private String name;
	private String carrier;
	private double price;
	
	public Ipad(String serialNum, String name, String carrier, double price) {
		super();
		this.serialNum = serialNum;
		this.name = name;
		this.carrier = carrier;
		this.price = price;
	}

	public String getSerialNum() {
		return serialNum;
	}

	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCarrier() {
		return carrier;
	}

	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Ipad [serialNum=" + serialNum + ", name=" + name + ", carrier=" + carrier + ", price=" + price + "]";
	}
	

}
