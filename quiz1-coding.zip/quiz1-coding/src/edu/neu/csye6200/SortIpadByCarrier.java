package edu.neu.csye6200;

import java.util.Comparator;

public class SortIpadByCarrier implements Comparator<Ipad> {
	@Override
	public int compare(Ipad o1, Ipad o2) {
		return o1.getCarrier().compareTo(o2.getCarrier());
	}
}
