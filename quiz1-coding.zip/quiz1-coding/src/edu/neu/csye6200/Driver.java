package edu.neu.csye6200;

public class Driver {
	public static void main(String[] args) {
		NEU neu = new NEU();
		neu.demo();
	}
}
/*
5 ipads in the following collection: DEFAULT SORT.
Ipad [serialNum=001, name=IPAD 2, carrier=ATT, price=599.9]
Ipad [serialNum=002, name=NEW IPAD PRO, carrier=WIFI, price=899.9]
Ipad [serialNum=003, name=NEW IPAD, carrier=ATT, price=799.9]
Ipad [serialNum=004, name=IPAD 6, carrier=VS, price=299.9]
Ipad [serialNum=007, name=IPAD 1, carrier=SoftBank, price=399.9]
5 ipads in the following collection: SORT BY SERIALNUM.
Ipad [serialNum=001, name=IPAD 2, carrier=ATT, price=599.9]
Ipad [serialNum=002, name=NEW IPAD PRO, carrier=WIFI, price=899.9]
Ipad [serialNum=003, name=NEW IPAD, carrier=ATT, price=799.9]
Ipad [serialNum=004, name=IPAD 6, carrier=VS, price=299.9]
Ipad [serialNum=007, name=IPAD 1, carrier=SoftBank, price=399.9]
5 ipads in the following collection: SORT BY NAME.
Ipad [serialNum=007, name=IPAD 1, carrier=SoftBank, price=399.9]
Ipad [serialNum=001, name=IPAD 2, carrier=ATT, price=599.9]
Ipad [serialNum=004, name=IPAD 6, carrier=VS, price=299.9]
Ipad [serialNum=003, name=NEW IPAD, carrier=ATT, price=799.9]
Ipad [serialNum=002, name=NEW IPAD PRO, carrier=WIFI, price=899.9]
5 ipads in the following collection: SORT BY CARRIER.
Ipad [serialNum=001, name=IPAD 2, carrier=ATT, price=599.9]
Ipad [serialNum=003, name=NEW IPAD, carrier=ATT, price=799.9]
Ipad [serialNum=007, name=IPAD 1, carrier=SoftBank, price=399.9]
Ipad [serialNum=004, name=IPAD 6, carrier=VS, price=299.9]
Ipad [serialNum=002, name=NEW IPAD PRO, carrier=WIFI, price=899.9]
5 ipads in the following collection: SORT BY PRICE.
Ipad [serialNum=004, name=IPAD 6, carrier=VS, price=299.9]
Ipad [serialNum=007, name=IPAD 1, carrier=SoftBank, price=399.9]
Ipad [serialNum=001, name=IPAD 2, carrier=ATT, price=599.9]
Ipad [serialNum=003, name=NEW IPAD, carrier=ATT, price=799.9]
Ipad [serialNum=002, name=NEW IPAD PRO, carrier=WIFI, price=899.9]
5 macbooks in the following collection: DEFAULT SORT.
Ipad [serialNum=005, name=MB 17, carrier=WIFI, price=899.9]
Ipad [serialNum=004, name=MB 13, carrier=ATT, price=1099.9]
Ipad [serialNum=001, name=NEW MB 13, carrier=WIFI, price=1299.9]
Ipad [serialNum=006, name=MB 16, carrier=WIFI, price=1699.9]
Ipad [serialNum=003, name=NEW MB 16, carrier=ATT, price=2299.9]
5 macbooks in the following collection: SORT BY SERIALNUM.
Ipad [serialNum=001, name=NEW MB 13, carrier=WIFI, price=1299.9]
Ipad [serialNum=003, name=NEW MB 16, carrier=ATT, price=2299.9]
Ipad [serialNum=004, name=MB 13, carrier=ATT, price=1099.9]
Ipad [serialNum=005, name=MB 17, carrier=WIFI, price=899.9]
Ipad [serialNum=006, name=MB 16, carrier=WIFI, price=1699.9]
5 macbooks in the following collection: SORT BY NAME.
Ipad [serialNum=004, name=MB 13, carrier=ATT, price=1099.9]
Ipad [serialNum=006, name=MB 16, carrier=WIFI, price=1699.9]
Ipad [serialNum=005, name=MB 17, carrier=WIFI, price=899.9]
Ipad [serialNum=001, name=NEW MB 13, carrier=WIFI, price=1299.9]
Ipad [serialNum=003, name=NEW MB 16, carrier=ATT, price=2299.9]
5 macbooks in the following collection: SORT BY CARRIER.
Ipad [serialNum=004, name=MB 13, carrier=ATT, price=1099.9]
Ipad [serialNum=003, name=NEW MB 16, carrier=ATT, price=2299.9]
Ipad [serialNum=006, name=MB 16, carrier=WIFI, price=1699.9]
Ipad [serialNum=005, name=MB 17, carrier=WIFI, price=899.9]
Ipad [serialNum=001, name=NEW MB 13, carrier=WIFI, price=1299.9]
5 macbooks in the following collection: SORT BY PRICE.
Ipad [serialNum=005, name=MB 17, carrier=WIFI, price=899.9]
Ipad [serialNum=004, name=MB 13, carrier=ATT, price=1099.9]
Ipad [serialNum=001, name=NEW MB 13, carrier=WIFI, price=1299.9]
Ipad [serialNum=006, name=MB 16, carrier=WIFI, price=1699.9]
Ipad [serialNum=003, name=NEW MB 16, carrier=ATT, price=2299.9]
BUILD SUCCESSFUL (total time: 1 second)
*/