package edu.neu.csye6200;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class NEU extends AbstractStoreAPI {
	private List<Ipad> ipads;
	private List<MacBook> macBooks;
	
	@Override
	public void addIpad(Ipad s) {
		ipads.add(s);
		Collections.sort(ipads, new SortIpadBySerialNum());
	}
	@Override
	public void addMacBook(MacBook s) {
		macBooks.add(s);
		Collections.sort(macBooks, new SortMacBookByPrice());
	}
	@Override
	public void sortIpad(Comparator c) {
		Collections.sort(ipads, c);
	}
	@Override
	public void sortMacBook(Comparator c) {
		Collections.sort(macBooks, c);
	}
	@Override
	public String toString() {
		String result = "";
		for (Ipad p : ipads) {
			result += (p.toString() + "\n");
		}
		for (MacBook m : macBooks) {
			result += (m.toString() + "\n");
		}
		return result;
	}
	
	public void demo() {
		ipads = new ArrayList<Ipad>();
		macBooks = new ArrayList<MacBook>();
		
		addIpad(new Ipad("001", "IPAD 2", "ATT", 599.9));
		addIpad(new Ipad("007", "IPAD 1", "SoftBank", 399.9));
		addIpad(new Ipad("004", "IPAD 6", "VS", 299.9));
		addIpad(new Ipad("003", "NEW IPAD", "ATT", 799.9));
		addIpad(new Ipad("002", "NEW IPAD PRO", "WIFI", 899.9));
		addMacBook(new MacBook("001", "NEW MB 13", "WIFI", 1299.9));
		addMacBook(new MacBook("003", "NEW MB 16", "ATT", 2299.9));
		addMacBook(new MacBook("005", "MB 17", "WIFI", 899.9));
		addMacBook(new MacBook("004", "MB 13", "ATT", 1099.9));
		addMacBook(new MacBook("006", "MB 16", "WIFI", 1699.9));
		
		System.out.println(ipads.size() + " ipads in the following collection: DEFAULT SORT.");
		ipads.forEach(System.out::println);
		System.out.println(ipads.size() + " ipads in the following collection: SORT BY SERIALNUM.");
		sortIpad(new SortIpadBySerialNum());
		ipads.forEach(System.out::println);
		System.out.println(ipads.size() + " ipads in the following collection: SORT BY NAME.");
		sortIpad(new SortIpadByName());
		ipads.forEach(System.out::println);
		System.out.println(ipads.size() + " ipads in the following collection: SORT BY CARRIER.");
		sortIpad(new SortIpadByCarrier());
		ipads.forEach(System.out::println);
		System.out.println(ipads.size() + " ipads in the following collection: SORT BY PRICE.");
		sortIpad(new SortIpadByPrice());
		ipads.forEach(System.out::println);
		
		System.out.println(macBooks.size() + " macbooks in the following collection: DEFAULT SORT.");
		macBooks.forEach(System.out::println);
		System.out.println(macBooks.size() + " macbooks in the following collection: SORT BY SERIALNUM.");
		sortMacBook(new SortMacBookBySerialNum());
		macBooks.forEach(System.out::println);
		System.out.println(macBooks.size() + " macbooks in the following collection: SORT BY NAME.");
		sortMacBook(new SortMacBookByName());
		macBooks.forEach(System.out::println);
		System.out.println(macBooks.size() + " macbooks in the following collection: SORT BY CARRIER.");
		sortMacBook(new SortMacBookByCarrier());
		macBooks.forEach(System.out::println);
		System.out.println(macBooks.size() + " macbooks in the following collection: SORT BY PRICE.");
		sortMacBook(new SortMacBookByPrice());
		macBooks.forEach(System.out::println);
	}

}
