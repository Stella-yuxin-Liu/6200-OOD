package edu.neu.csye6200;

import java.util.Comparator;

/**
 * API for all store models which
 * 1. sells different items
 * 
 *
 */
public abstract class AbstractStoreAPI {
    public abstract void addIpad(Ipad s);
    public abstract void addMacBook(MacBook s);
    public abstract void sortIpad(Comparator c);
    public abstract void sortMacbook(Comparator c);
}

