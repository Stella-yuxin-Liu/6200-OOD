package edu.neu.csye6200;

import java.util.Comparator;

public class SortIpadByName implements Comparator<Ipad> {
	@Override
	public int compare(Ipad o1, Ipad o2) {
		return o1.getName().compareTo(o2.getName());
	}
}
