package edu.neu.csye6200;

import java.util.Comparator;

public class SortMacBookByName implements Comparator<MacBook> {
	@Override
	public int compare(MacBook o1, MacBook o2) {
		return o1.getName().compareTo(o2.getName());
	}
}
