package edu.neu.csye6200;



import java.util.Comparator;

public class SortIpadByPrice implements Comparator<Ipad> {
	@Override
	public int compare(Ipad o1, Ipad o2) {
		return Double.compare(o1.getPrice(), o2.getPrice());
	}
}